from __future__ import unicode_literals

STATUS_OK = 'Ok'
STATUS_FAIL = 'Failed'
STATUS_USER_DOES_NOT_EXIST = 'No such user'
STATUS_INVALID_TOKEN = 'Bad authentication'

