/**
 * Top bar foundation menu
 * */


angular.module("serafinTopbarMenu", ["mm.foundation"])
    .controller("TopbarMenuController", function($scope) {
        // This is intentionally left empty. We're using the django-sitetree
        // template tags to build the menu.
    });