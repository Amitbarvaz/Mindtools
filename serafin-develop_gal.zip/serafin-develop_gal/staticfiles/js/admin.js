(function ($) {

    $('#language-switcher select').on('change', function() {
        $('#language-switcher').submit()
    })

}(jQuery));
