from django.apps import AppConfig, apps


class UsersConfig(AppConfig):
    name = 'users'
